(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var bulkCollectionUpdate;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/udondan_bulk-collection-update/packages/udondan_bulk-collection-update.js                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
(function () {                                                                                                         // 1
                                                                                                                       // 2
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/udondan:bulk-collection-update/lib/bulkCollectionUpdate.js                                              //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var Fiber = Npm.require("fibers");                                                                                  // 1
                                                                                                                    // 2
bulkCollectionUpdate = function(collection, data, options) {                                                        // 3
                                                                                                                    // 4
  // set defaults                                                                                                   // 5
  var options = options || {};                                                                                      // 6
  options["deleteMissing"] = options["deleteMissing"] || false;                                                     // 7
  options["primaryKey"] = options["primaryKey"] || "_id";                                                           // 8
                                                                                                                    // 9
  // holds all data elements, where the primaryKey is the key - for easy access at the delete routine               // 10
  var objByKey = {};                                                                                                // 11
                                                                                                                    // 12
  // validation of parameters                                                                                       // 13
  if (typeof collection !== "object" || typeof collection._collection !== "object") {                               // 14
    throw '"collection" is no valid meteor collection';                                                             // 15
  }                                                                                                                 // 16
  if (typeof data !== "object" || Object.prototype.toString.call(data) !== "[object Array]") {                      // 17
    throw '"data" is not of type array';                                                                            // 18
  }                                                                                                                 // 19
  if (typeof options.primaryKey !== "string" || (data.length && typeof data[0][options.primaryKey] !== "string")) { // 20
    throw '"primaryKey" is no valid object property';                                                               // 21
  }                                                                                                                 // 22
                                                                                                                    // 23
                                                                                                                    // 24
  Fiber(function () {                                                                                               // 25
                                                                                                                    // 26
    // iterate through all elements of data                                                                         // 27
    _.each(data, function (document) {                                                                              // 28
                                                                                                                    // 29
      // save elements with the primary key as property name for later use                                          // 30
      objByKey[document[options.primaryKey]] = document;                                                            // 31
                                                                                                                    // 32
      // build the condition for upsert                                                                             // 33
      var condition = {};                                                                                           // 34
      condition[options.primaryKey] = document[options.primaryKey];                                                 // 35
                                                                                                                    // 36
      // insert or update, depending on the previosuly built condition (=primaryKey exists)                         // 37
      collection.upsert(                                                                                            // 38
        condition,                                                                                                  // 39
        {                                                                                                           // 40
          $set: document                                                                                            // 41
        }                                                                                                           // 42
      );                                                                                                            // 43
    });                                                                                                             // 44
                                                                                                                    // 45
    // if we should delete elements which were not contained in data                                                // 46
    if (options.deleteMissing === true) {                                                                           // 47
                                                                                                                    // 48
      // limit returned fields to only _id and the primaryKey                                                       // 49
      var fields = {};                                                                                              // 50
      fields[options.primaryKey] = true;                                                                            // 51
                                                                                                                    // 52
      // iterate through all returned documents                                                                     // 53
      _.each(collection.find({},{ fields: fields }).fetch(), function(document) {                                   // 54
                                                                                                                    // 55
        // if document was not contained in data                                                                    // 56
        if (typeof objByKey[document[options.primaryKey]] === "undefined") {                                        // 57
                                                                                                                    // 58
          // delete from collection                                                                                 // 59
          collection.remove(document._id);                                                                          // 60
        }                                                                                                           // 61
      });                                                                                                           // 62
    }                                                                                                               // 63
                                                                                                                    // 64
    // fire callback                                                                                                // 65
    if (typeof options.callback === "function") {                                                                   // 66
      options.callback();                                                                                           // 67
    }                                                                                                               // 68
                                                                                                                    // 69
  }).run();                                                                                                         // 70
                                                                                                                    // 71
};                                                                                                                  // 72
                                                                                                                    // 73
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       // 83
}).call(this);                                                                                                         // 84
                                                                                                                       // 85
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['udondan:bulk-collection-update'] = {
  bulkCollectionUpdate: bulkCollectionUpdate
};

})();

//# sourceMappingURL=udondan_bulk-collection-update.js.map
