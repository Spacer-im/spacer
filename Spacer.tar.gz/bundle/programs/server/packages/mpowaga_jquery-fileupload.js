(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/mpowaga_jquery-fileupload/packages/mpowaga_jquery-fileup //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mpowaga:jquery-fileupload'] = {};

})();

//# sourceMappingURL=mpowaga_jquery-fileupload.js.map
