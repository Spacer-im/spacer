(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////
//                                                                                       //
// packages/dferber_prerender/server/prerender.js                                        //
//                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////
                                                                                         //
var prerenderio = Npm.require('prerender-node');                                         // 1
var token;                                                                               // 2
var serviceUrl;                                                                          // 3
var settings = Meteor.settings.PrerenderIO;                                              // 4
                                                                                         // 5
// token                                                                                 // 6
token = process.env.PRERENDERIO_TOKEN || (settings && settings.token);                   // 7
                                                                                         // 8
// service url (support `prerenderServiceUrl` (for historical reasons) and `serviceUrl`)
serviceUrl = settings && (settings.prerenderServiceUrl || settings.serviceUrl);          // 10
serviceUrl = process.env.PRERENDERIO_SERVICE_URL || serviceUrl;                          // 11
                                                                                         // 12
if (token) {                                                                             // 13
  if (serviceUrl) prerenderio.set('prerenderServiceUrl', serviceUrl);                    // 14
  prerenderio.set('prerenderToken', token);                                              // 15
                                                                                         // 16
  prerenderio.set('afterRender', function afterRender(error) {                           // 17
    if (error) {                                                                         // 18
      console.log('prerenderio error', error); // eslint-disable-line no-console         // 19
      return;                                                                            // 20
    }                                                                                    // 21
  });                                                                                    // 22
                                                                                         // 23
  WebApp.rawConnectHandlers.use(prerenderio);                                            // 24
}                                                                                        // 25
                                                                                         // 26
///////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['dferber:prerender'] = {};

})();

//# sourceMappingURL=dferber_prerender.js.map
