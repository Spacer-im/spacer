(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var FS = Package['cfs:base-package'].FS;

/* Package-scope variables */
var AWS;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/cfs_s3/packages/cfs_s3.js                                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
(function () {                                                                                                     // 1
                                                                                                                   // 2
//////////////////////////////////////////////////////////////////////////////////////////////////////////////     // 3
//                                                                                                          //     // 4
// packages/cfs:s3/s3.server.js                                                                             //     // 5
//                                                                                                          //     // 6
//////////////////////////////////////////////////////////////////////////////////////////////////////////////     // 7
                                                                                                            //     // 8
// We use the official aws sdk                                                                              // 1   // 9
AWS = Npm.require('aws-sdk');                                                                               // 2   // 10
                                                                                                            // 3   // 11
var validS3ServiceParamKeys = [                                                                             // 4   // 12
  'endpoint',                                                                                               // 5   // 13
  'accessKeyId',                                                                                            // 6   // 14
  'secretAccessKey',                                                                                        // 7   // 15
  'sessionToken',                                                                                           // 8   // 16
  'credentials',                                                                                            // 9   // 17
  'credentialProvider',                                                                                     // 10  // 18
  'region',                                                                                                 // 11  // 19
  'maxRetries',                                                                                             // 12  // 20
  'maxRedirects',                                                                                           // 13  // 21
  'sslEnabled',                                                                                             // 14  // 22
  'paramValidation',                                                                                        // 15  // 23
  'computeChecksums',                                                                                       // 16  // 24
  's3ForcePathStyle',                                                                                       // 17  // 25
  'httpOptions',                                                                                            // 18  // 26
  'apiVersion',                                                                                             // 19  // 27
  'apiVersions',                                                                                            // 20  // 28
  'logger',                                                                                                 // 21  // 29
  'signatureVersion'                                                                                        // 22  // 30
];                                                                                                          // 23  // 31
var validS3PutParamKeys = [                                                                                 // 24  // 32
  'ACL',                                                                                                    // 25  // 33
  'Body',                                                                                                   // 26  // 34
  'Bucket',                                                                                                 // 27  // 35
  'CacheControl',                                                                                           // 28  // 36
  'ContentDisposition',                                                                                     // 29  // 37
  'ContentEncoding',                                                                                        // 30  // 38
  'ContentLanguage',                                                                                        // 31  // 39
  'ContentLength',                                                                                          // 32  // 40
  'ContentMD5',                                                                                             // 33  // 41
  'ContentType',                                                                                            // 34  // 42
  'Expires',                                                                                                // 35  // 43
  'GrantFullControl',                                                                                       // 36  // 44
  'GrantRead',                                                                                              // 37  // 45
  'GrantReadACP',                                                                                           // 38  // 46
  'GrantWriteACP',                                                                                          // 39  // 47
  'Key',                                                                                                    // 40  // 48
  'Metadata',                                                                                               // 41  // 49
  'ServerSideEncryption',                                                                                   // 42  // 50
  'StorageClass',                                                                                           // 43  // 51
  'WebsiteRedirectLocation'                                                                                 // 44  // 52
];                                                                                                          // 45  // 53
                                                                                                            // 46  // 54
/**                                                                                                         // 47  // 55
 * @public                                                                                                  // 48  // 56
 * @constructor                                                                                             // 49  // 57
 * @param {String} name - The store name                                                                    // 50  // 58
 * @param {Object} options                                                                                  // 51  // 59
 * @param {String} options.region - Bucket region                                                           // 52  // 60
 * @param {String} options.bucket - Bucket name                                                             // 53  // 61
 * @param {String} [options.accessKeyId] - AWS IAM key; required if not set in environment variables        // 54  // 62
 * @param {String} [options.secretAccessKey] - AWS IAM secret; required if not set in environment variables // 55  // 63
 * @param {String} [options.ACL='private'] - ACL for objects when putting                                   // 56  // 64
 * @param {String} [options.folder='/'] - Which folder (key prefix) in the bucket to use                    // 57  // 65
 * @param {Function} [options.beforeSave] - Function to run before saving a file from the server. The context of the function will be the `FS.File` instance we're saving. The function may alter its properties.
 * @param {Number} [options.maxTries=5] - Max times to attempt saving a file                                // 59  // 67
 * @returns {FS.StorageAdapter} An instance of FS.StorageAdapter.                                           // 60  // 68
 *                                                                                                          // 61  // 69
 * Creates an S3 store instance on the server. Inherits from FS.StorageAdapter                              // 62  // 70
 * type.                                                                                                    // 63  // 71
 */                                                                                                         // 64  // 72
FS.Store.S3 = function(name, options) {                                                                     // 65  // 73
  var self = this;                                                                                          // 66  // 74
  if (!(self instanceof FS.Store.S3))                                                                       // 67  // 75
    throw new Error('FS.Store.S3 missing keyword "new"');                                                   // 68  // 76
                                                                                                            // 69  // 77
  options = options || {};                                                                                  // 70  // 78
                                                                                                            // 71  // 79
  // Determine which folder (key prefix) in the bucket to use                                               // 72  // 80
  var folder = options.folder;                                                                              // 73  // 81
  if (typeof folder === "string" && folder.length) {                                                        // 74  // 82
    if (folder.slice(0, 1) === "/") {                                                                       // 75  // 83
      folder = folder.slice(1);                                                                             // 76  // 84
    }                                                                                                       // 77  // 85
    if (folder.slice(-1) !== "/") {                                                                         // 78  // 86
      folder += "/";                                                                                        // 79  // 87
    }                                                                                                       // 80  // 88
  } else {                                                                                                  // 81  // 89
    folder = "";                                                                                            // 82  // 90
  }                                                                                                         // 83  // 91
                                                                                                            // 84  // 92
  var bucket = options.bucket;                                                                              // 85  // 93
  if (!bucket)                                                                                              // 86  // 94
    throw new Error('FS.Store.S3 you must specify the "bucket" option');                                    // 87  // 95
                                                                                                            // 88  // 96
  var defaultAcl = options.ACL || 'private';                                                                // 89  // 97
                                                                                                            // 90  // 98
  // Remove serviceParams from SA options                                                                   // 91  // 99
 // options = _.omit(options, validS3ServiceParamKeys);                                                     // 92  // 100
                                                                                                            // 93  // 101
  var serviceParams = FS.Utility.extend({                                                                   // 94  // 102
    Bucket: bucket,                                                                                         // 95  // 103
    region: null, //required                                                                                // 96  // 104
    accessKeyId: null, //required                                                                           // 97  // 105
    secretAccessKey: null, //required                                                                       // 98  // 106
    ACL: defaultAcl                                                                                         // 99  // 107
  }, options);                                                                                              // 100
                                                                                                            // 101
  // Whitelist serviceParams, else aws-sdk throws an error                                                  // 102
  // XXX: I've commented this at the moment... It stopped things from working                               // 103
  // we have to check up on this                                                                            // 104
  // serviceParams = _.pick(serviceParams, validS3ServiceParamKeys);                                        // 105
                                                                                                            // 106
  // Create S3 service                                                                                      // 107
  var S3 = new AWS.S3(serviceParams);                                                                       // 108
                                                                                                            // 109
  return new FS.StorageAdapter(name, options, {                                                             // 110
    typeName: 'storage.s3',                                                                                 // 111
    fileKey: function(fileObj) {                                                                            // 112
      // Lookup the copy                                                                                    // 113
      var info = fileObj && fileObj._getInfo(name);                                                         // 114
      // If the store and key is found return the key                                                       // 115
      if (info && info.key) return info.key;                                                                // 116
                                                                                                            // 117
      var filename = fileObj.name();                                                                        // 118
      var filenameInStore = fileObj.name({store: name});                                                    // 119
                                                                                                            // 120
      // If no store key found we resolve / generate a key                                                  // 121
      return fileObj.collectionName + '/' + fileObj._id + '-' + (filenameInStore || filename);              // 122
    },                                                                                                      // 123
    createReadStream: function(fileKey, options) {                                                          // 124
                                                                                                            // 125
      return S3.createReadStream({                                                                          // 126
        Bucket: bucket,                                                                                     // 127
        Key: folder + fileKey                                                                               // 128
      });                                                                                                   // 129
                                                                                                            // 130
    },                                                                                                      // 131
    // Comment to documentation: Set options.ContentLength otherwise the                                    // 132
    // indirect stream will be used creating extra overhead on the filesystem.                              // 133
    // An easy way if the data is not transformed is to set the                                             // 134
    // options.ContentLength = fileObj.size ...                                                             // 135
    createWriteStream: function(fileKey, options) {                                                         // 136
      options = options || {};                                                                              // 137
                                                                                                            // 138
      if (options.contentType) {                                                                            // 139
        options.ContentType = options.contentType;                                                          // 140
      }                                                                                                     // 141
                                                                                                            // 142
      // We dont support array of aliases                                                                   // 143
      delete options.aliases;                                                                               // 144
      // We dont support contentType                                                                        // 145
      delete options.contentType;                                                                           // 146
      // We dont support metadata use Metadata?                                                             // 147
      delete options.metadata;                                                                              // 148
                                                                                                            // 149
      // Set options                                                                                        // 150
      var options = FS.Utility.extend({                                                                     // 151
        Bucket: bucket,                                                                                     // 152
        Key: folder + fileKey,                                                                              // 153
        fileKey: fileKey,                                                                                   // 154
        ACL: defaultAcl                                                                                     // 155
      }, options);                                                                                          // 156
                                                                                                            // 157
      return S3.createWriteStream(options);                                                                 // 158
    },                                                                                                      // 159
    remove: function(fileKey, callback) {                                                                   // 160
                                                                                                            // 161
      S3.deleteObject({                                                                                     // 162
        Bucket: bucket,                                                                                     // 163
        Key: folder + fileKey                                                                               // 164
      }, function(error) {                                                                                  // 165
        callback(error, !error);                                                                            // 166
      });                                                                                                   // 167
    },                                                                                                      // 168
    watch: function() {                                                                                     // 169
      throw new Error("S3 storage adapter does not support the sync option");                               // 170
    }                                                                                                       // 171
  });                                                                                                       // 172
};                                                                                                          // 173
                                                                                                            // 174
//////////////////////////////////////////////////////////////////////////////////////////////////////////////     // 183
                                                                                                                   // 184
}).call(this);                                                                                                     // 185
                                                                                                                   // 186
                                                                                                                   // 187
                                                                                                                   // 188
                                                                                                                   // 189
                                                                                                                   // 190
                                                                                                                   // 191
(function () {                                                                                                     // 192
                                                                                                                   // 193
//////////////////////////////////////////////////////////////////////////////////////////////////////////////     // 194
//                                                                                                          //     // 195
// packages/cfs:s3/s3.upload.stream2.js                                                                     //     // 196
//                                                                                                          //     // 197
//////////////////////////////////////////////////////////////////////////////////////////////////////////////     // 198
                                                                                                            //     // 199
var Writable = Npm.require('stream').Writable;                                                              // 1   // 200
                                                                                                            // 2   // 201
// This is based on the code from                                                                           // 3   // 202
// https://github.com/nathanpeck/s3-upload-stream/blob/master/lib/s3-upload-stream.js                       // 4   // 203
// But much is rewritten and adapted to cfs                                                                 // 5   // 204
                                                                                                            // 6   // 205
AWS.S3.prototype.createReadStream = function(params, options) {                                             // 7   // 206
  // Simple wrapper                                                                                         // 8   // 207
  return this.getObject(params).createReadStream();                                                         // 9   // 208
};                                                                                                          // 10  // 209
                                                                                                            // 11  // 210
// Extend the AWS.S3 API                                                                                    // 12  // 211
AWS.S3.prototype.createWriteStream = function(params, options) {                                            // 13  // 212
  var self = this;                                                                                          // 14  // 213
                                                                                                            // 15  // 214
  //Create the writeable stream interface.                                                                  // 16  // 215
  var writeStream = Writable({                                                                              // 17  // 216
    highWaterMark: 4194304 // 4 MB                                                                          // 18  // 217
  });                                                                                                       // 19  // 218
                                                                                                            // 20  // 219
  var partNumber = 1;                                                                                       // 21  // 220
  var parts = [];                                                                                           // 22  // 221
  var receivedSize = 0;                                                                                     // 23  // 222
  var uploadedSize = 0;                                                                                     // 24  // 223
  var currentChunk = Buffer(0);                                                                             // 25  // 224
  var maxChunkSize = 5242880;                                                                               // 26  // 225
  var multipartUploadID = null;                                                                             // 27  // 226
  var waitingCallback;                                                                                      // 28  // 227
  var fileKey = params && (params.fileKey || params.Key);                                                   // 29  // 228
                                                                                                            // 30  // 229
  // Clean up for AWS sdk                                                                                   // 31  // 230
  delete params.fileKey;                                                                                    // 32  // 231
                                                                                                            // 33  // 232
  // This small function stops the write stream until we have connected with                                // 34  // 233
  // the s3 server                                                                                          // 35  // 234
  var runWhenReady = function(callback) {                                                                   // 36  // 235
    // If we dont have a upload id we are not ready                                                         // 37  // 236
    if (multipartUploadID === null) {                                                                       // 38  // 237
      // We set the waiting callback                                                                        // 39  // 238
      waitingCallback = callback;                                                                           // 40  // 239
    } else {                                                                                                // 41  // 240
      // No problem - just continue                                                                         // 42  // 241
      callback();                                                                                           // 43  // 242
    }                                                                                                       // 44  // 243
  };                                                                                                        // 45  // 244
                                                                                                            // 46  // 245
  //Handler to receive data and upload it to S3.                                                            // 47  // 246
  writeStream._write = function (chunk, enc, next) {                                                        // 48  // 247
    currentChunk = Buffer.concat([currentChunk, chunk]);                                                    // 49  // 248
                                                                                                            // 50  // 249
    // If the current chunk buffer is getting to large, or the stream piped in                              // 51  // 250
    // has ended then flush the chunk buffer downstream to S3 via the multipart                             // 52  // 251
    // upload API.                                                                                          // 53  // 252
    if(currentChunk.length > maxChunkSize) {                                                                // 54  // 253
      // Make sure we only run when the s3 upload is ready                                                  // 55  // 254
      runWhenReady(function() { flushChunk(next, false); });                                                // 56  // 255
    } else {                                                                                                // 57  // 256
      // We dont have to contact s3 for this                                                                // 58  // 257
      runWhenReady(next);                                                                                   // 59  // 258
    }                                                                                                       // 60  // 259
  };                                                                                                        // 61  // 260
                                                                                                            // 62  // 261
  // Overwrite the end method so that we can hijack it to flush the last part                               // 63  // 262
  // and then complete the multipart upload                                                                 // 64  // 263
  var _originalEnd = writeStream.end;                                                                       // 65  // 264
  writeStream.end = function (chunk, encoding, callback) {                                                  // 66  // 265
    // Call the super                                                                                       // 67  // 266
    _originalEnd.call(this, chunk, encoding, function () {                                                  // 68  // 267
      // Make sure we only run when the s3 upload is ready                                                  // 69  // 268
      runWhenReady(function() { flushChunk(callback, true); });                                             // 70  // 269
    });                                                                                                     // 71  // 270
  };                                                                                                        // 72  // 271
                                                                                                            // 73  // 272
  writeStream.on('error', function () {                                                                     // 74  // 273
    if (multipartUploadID) {                                                                                // 75  // 274
      if (FS.debug) {                                                                                       // 76  // 275
        console.log('SA S3 - ERROR!!');                                                                     // 77  // 276
      }                                                                                                     // 78  // 277
      self.abortMultipartUpload({                                                                           // 79  // 278
        Bucket: params.Bucket,                                                                              // 80  // 279
        Key: params.Key,                                                                                    // 81  // 280
        UploadId: multipartUploadID                                                                         // 82  // 281
      }, function (err) {                                                                                   // 83  // 282
        if(err) {                                                                                           // 84  // 283
          console.error('SA S3 - Could not abort multipart upload', err)                                    // 85  // 284
        }                                                                                                   // 86  // 285
      });                                                                                                   // 87  // 286
    }                                                                                                       // 88  // 287
  });                                                                                                       // 89  // 288
                                                                                                            // 90  // 289
  var flushChunk = function (callback, lastChunk) {                                                         // 91  // 290
    if (multipartUploadID === null) {                                                                       // 92  // 291
      throw new Error('Internal error multipartUploadID is null');                                          // 93  // 292
    }                                                                                                       // 94  // 293
    // Get the chunk data                                                                                   // 95  // 294
    var uploadingChunk = Buffer(currentChunk.length);                                                       // 96  // 295
    currentChunk.copy(uploadingChunk);                                                                      // 97  // 296
                                                                                                            // 98  // 297
                                                                                                            // 99  // 298
    // Store the current part number and then increase the counter                                          // 100
    var localChunkNumber = partNumber++;                                                                    // 101
                                                                                                            // 102
    // We add the size of data                                                                              // 103
    receivedSize += uploadingChunk.length;                                                                  // 104
                                                                                                            // 105
    // Upload the part                                                                                      // 106
    self.uploadPart({                                                                                       // 107
      Body: uploadingChunk,                                                                                 // 108
      Bucket: params.Bucket,                                                                                // 109
      Key: params.Key,                                                                                      // 110
      UploadId: multipartUploadID,                                                                          // 111
      PartNumber: localChunkNumber                                                                          // 112
    }, function (err, result) {                                                                             // 113
      // Call the next data                                                                                 // 114
      if(typeof callback === 'function') {                                                                  // 115
        callback();                                                                                         // 116
      }                                                                                                     // 117
                                                                                                            // 118
      if(err) {                                                                                             // 119
        writeStream.emit('error', err);                                                                     // 120
      } else {                                                                                              // 121
        // Increase the upload size                                                                         // 122
        uploadedSize += uploadingChunk.length;                                                              // 123
        parts[localChunkNumber-1] = {                                                                       // 124
          ETag: result.ETag,                                                                                // 125
          PartNumber: localChunkNumber                                                                      // 126
        };                                                                                                  // 127
                                                                                                            // 128
        // XXX: event for debugging                                                                         // 129
        writeStream.emit('chunk', {                                                                         // 130
          ETag: result.ETag,                                                                                // 131
          PartNumber: localChunkNumber,                                                                     // 132
          receivedSize: receivedSize,                                                                       // 133
          uploadedSize: uploadedSize                                                                        // 134
        });                                                                                                 // 135
                                                                                                            // 136
        // The incoming stream has finished giving us all data and we have                                  // 137
        // finished uploading all that data to S3. So tell S3 to assemble those                             // 138
        // parts we uploaded into the final product.                                                        // 139
        if(writeStream._writableState.ended === true &&                                                     // 140
                uploadedSize === receivedSize && lastChunk) {                                               // 141
          // Complete the upload                                                                            // 142
          self.completeMultipartUpload({                                                                    // 143
            Bucket: params.Bucket,                                                                          // 144
            Key: params.Key,                                                                                // 145
            UploadId: multipartUploadID,                                                                    // 146
            MultipartUpload: {                                                                              // 147
              Parts: parts                                                                                  // 148
            }                                                                                               // 149
          }, function (err, result) {                                                                       // 150
            if(err) {                                                                                       // 151
              writeStream.emit('error', err);                                                               // 152
            } else {                                                                                        // 153
              // Emit the cfs end event for uploads                                                         // 154
              if (FS.debug) {                                                                               // 155
                console.log('SA S3 - DONE!!');                                                              // 156
              }                                                                                             // 157
              writeStream.emit('stored', {                                                                  // 158
                fileKey: fileKey,                                                                           // 159
                size: uploadedSize,                                                                         // 160
                storedAt: new Date()                                                                        // 161
              });                                                                                           // 162
            }                                                                                               // 163
                                                                                                            // 164
          });                                                                                               // 165
        }                                                                                                   // 166
      }                                                                                                     // 167
    });                                                                                                     // 168
                                                                                                            // 169
    // Reset the current buffer                                                                             // 170
    currentChunk = Buffer(0);                                                                               // 171
  };                                                                                                        // 172
                                                                                                            // 173
  //Use the S3 client to initialize a multipart upload to S3.                                               // 174
  self.createMultipartUpload( params, function (err, data) {                                                // 175
    if(err) {                                                                                               // 176
      // Emit the error                                                                                     // 177
      writeStream.emit('error', err);                                                                       // 178
    } else {                                                                                                // 179
      // Set the upload id                                                                                  // 180
      multipartUploadID = data.UploadId;                                                                    // 181
                                                                                                            // 182
      // Call waiting callback                                                                              // 183
      if (typeof waitingCallback === 'function') {                                                          // 184
        // We call the waiting callback if any now since we established a                                   // 185
        // connection to the s3                                                                             // 186
        waitingCallback();                                                                                  // 187
      }                                                                                                     // 188
                                                                                                            // 189
    }                                                                                                       // 190
  });                                                                                                       // 191
                                                                                                            // 192
  // We return the write stream                                                                             // 193
  return writeStream;                                                                                       // 194
};                                                                                                          // 195
                                                                                                            // 196
//////////////////////////////////////////////////////////////////////////////////////////////////////////////     // 396
                                                                                                                   // 397
}).call(this);                                                                                                     // 398
                                                                                                                   // 399
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['cfs:s3'] = {};

})();

//# sourceMappingURL=cfs_s3.js.map
