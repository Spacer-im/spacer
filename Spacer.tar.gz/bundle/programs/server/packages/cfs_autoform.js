(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/cfs_autoform/packages/cfs_autoform.js                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['cfs:autoform'] = {};

})();

//# sourceMappingURL=cfs_autoform.js.map
