(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// methods/profile.js                                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
function checkIsUser() {                                               // 1
    if (!Meteor.userId()) {                                            // 2
        throw new Meteor.Error("not-authorized");                      // 3
    }                                                                  //
}                                                                      //
                                                                       //
Meteor.methods({                                                       // 7
    saveProfile: function (doc) {                                      // 8
        check(doc, Schemas.UserProfile);                               // 9
        if (!Meteor.userId()) {                                        // 10
            throw new Meteor.Error("not-authorized");                  // 11
        }                                                              //
        var links = doc.links || {};                                   // 13
        Meteor.users.update(Meteor.userId(), {                         // 14
            $set: {                                                    // 15
                "profile.photoId": doc.photoId || null,                // 16
                "profile.firstName": doc.firstName || null,            // 17
                "profile.lastName": doc.lastName || null,              // 18
                "profile.calling": doc.calling || null,                // 19
                "profile.location": doc.location || null,              // 20
                "profile.professions": doc.professions || null,        // 21
                "profile.summary": doc.summary || null,                // 22
                "profile.links.website": links.website || null,        // 23
                "profile.links.linkedin": links.linkedin || null,      // 24
                "profile.links.twitter": links.twitter || null,        // 25
                "profile.links.facebook": links.facebook || null,      // 26
                "profile.links.github": links.github || null,          // 27
                "profile.links.gplus": links.gplus || null             // 28
            }                                                          //
        });                                                            //
    },                                                                 //
    addEducation: function (doc) {                                     // 32
        checkIsUser();                                                 // 33
        Meteor.users.update(Meteor.userId(), { $push: { "profile.education": doc } });
    },                                                                 //
    editEducation: function (obj) {                                    // 36
        var doc = obj.$set;                                            // 37
        if (!doc || !doc.id) {                                         // 38
            throw new Meteor.Error("Education edit data or id not found");
        }                                                              //
        check(doc, Schemas.Education);                                 // 41
        checkIsUser();                                                 // 42
        Meteor.users.update({ "_id": Meteor.userId(), "profile.education.id": doc.id }, {
            $set: {                                                    // 44
                "profile.education.$.id": doc.id,                      // 45
                "profile.education.$.schoolName": doc.schoolName || null,
                "profile.education.$.gradeYear": doc.gradeYear || null,
                "profile.education.$.fieldOfStudy": doc.fieldOfStudy || null
            }                                                          //
        });                                                            //
    },                                                                 //
                                                                       //
    removeEducation: function (id) {                                   // 53
        checkIsUser();                                                 // 54
        Meteor.users.update(Meteor.userId(), {                         // 55
            $pull: {                                                   // 56
                "profile.education": { "id": id }                      // 57
            }                                                          //
        });                                                            //
    },                                                                 //
    addExperience: function (doc) {                                    // 61
        checkIsUser();                                                 // 62
        doc.id = Random.id();                                          // 63
        Meteor.users.update(Meteor.userId(), {                         // 64
            $push: {                                                   // 65
                "profile.experience": doc                              // 66
            }                                                          //
        });                                                            //
    },                                                                 //
    editExperience: function (obj) {                                   // 70
        var doc = obj.$set;                                            // 71
        if (!doc || !doc.id) {                                         // 72
            throw new Meteor.Error("Experience edit data or id not found");
        }                                                              //
        check(doc, Schemas.Experience);                                // 75
        checkIsUser();                                                 // 76
        Meteor.users.update({ "_id": Meteor.userId(), "profile.experience.id": doc.id }, {
            $set: {                                                    // 78
                "profile.experience.$.id": doc.id,                     // 79
                "profile.experience.$.company": doc.company || null,   // 80
                "profile.experience.$.title": doc.title || null,       // 81
                "profile.experience.$.dates": doc.dates || null,       // 82
                "profile.experience.$.description": doc.description || null
            }                                                          //
        });                                                            //
    },                                                                 //
                                                                       //
    removeExperience: function (id) {                                  // 88
        checkIsUser();                                                 // 89
        Meteor.users.update(Meteor.userId(), {                         // 90
            $pull: {                                                   // 91
                "profile.experience": { "id": id }                     // 92
            }                                                          //
        });                                                            //
    },                                                                 //
    addPersonalProject: function (doc) {                               // 96
        checkIsUser();                                                 // 97
        Meteor.users.update(Meteor.userId(), {                         // 98
            $push: {                                                   // 99
                "profile.projects": doc                                // 100
            }                                                          //
        });                                                            //
    },                                                                 //
    editPersonalProject: function (obj) {                              // 104
        var doc = obj.$set;                                            // 105
        if (!doc || !doc.id) {                                         // 106
            throw new Meteor.Error("Projects edit data or id not found");
        }                                                              //
        check(doc, Schemas.PersonalProject);                           // 109
        checkIsUser();                                                 // 110
        Meteor.users.update({ "_id": Meteor.userId(), "profile.projects.id": doc.id }, {
            $set: {                                                    // 112
                "profile.projects.$.id": doc.id,                       // 113
                "profile.projects.$.projectName": doc.projectName || null,
                "profile.projects.$.description": doc.description || null,
                "profile.projects.$.imageId": doc.imageId || null      // 116
            }                                                          //
        });                                                            //
    },                                                                 //
                                                                       //
    removePersonalProject: function (id) {                             // 121
        checkIsUser();                                                 // 122
        Meteor.users.update(Meteor.userId(), {                         // 123
            $pull: {                                                   // 124
                "profile.projects": { "id": id }                       // 125
            }                                                          //
        });                                                            //
    },                                                                 //
                                                                       //
    clearTempAvatars: function (protectedId) {                         // 130
        if (!Meteor.userId()) {                                        // 131
            return null;                                               // 132
        }                                                              //
        var actualAvatarId = Meteor.user().profile && Meteor.user().profile.photoId;
        Avatars.find({ owner: Meteor.userId() }).forEach(function (doc) {
            if (doc._id === actualAvatarId || doc._id === protectedId) {
                return true;                                           // 137
            }                                                          //
            Avatars.remove(doc._id, function (err) {                   // 139
                if (err) {                                             // 140
                    console.error(err);                                // 141
                }                                                      //
            });                                                        //
        });                                                            //
    },                                                                 //
                                                                       //
    clearProjectImages: function (protectedId) {                       // 148
        if (!Meteor.userId()) {                                        // 149
            return null;                                               // 150
        }                                                              //
        var userProjects = Meteor.user().profile && Meteor.user().profile.projects || [];
        var userImageIds = userProjects.map(function (el) {            // 153
            return el.imageId;                                         // 154
        }).filter(function (el) {                                      //
            return !!el;                                               //
        });                                                            //
        UserImages.find({ owner: Meteor.userId() }).forEach(function (doc) {
            if (userImageIds.indexOf(doc._id) !== -1 || doc._id === protectedId) {
                return true;                                           // 158
            }                                                          //
            UserImages.remove(doc._id, function (err) {                // 160
                if (err) {                                             // 161
                    console.error(err);                                // 162
                }                                                      //
            });                                                        //
        });                                                            //
    }                                                                  //
                                                                       //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=profile.js.map
