(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// methods/companies.js                                                //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.methods({                                                       // 1
    updateFromGlassDoor: function (companyId) {                        // 2
        if (!Meteor.userId() || !Roles.userIsInRole(Meteor.userId(), ['admin'])) {
            throw new Meteor.Error("not-authorized");                  // 4
        }                                                              //
        var company = Companies.findOne(companyId);                    // 6
        if (!company.glassDoorId) {                                    // 7
            console.error("Not Found glassDoorId for " + companyId);   // 8
            return false;                                              // 9
        }                                                              //
        if (Meteor.isServer) {                                         // 11
            GlassDoor.getInfo(company.name, company.glassDoorId, function (data) {
                Companies.update(companyId, { $set: { glassDoorData: data } });
            });                                                        //
        }                                                              //
    }                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=companies.js.map
