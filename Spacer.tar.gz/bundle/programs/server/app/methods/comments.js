(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// methods/comments.js                                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.methods({                                                       // 1
    addProjectComment: function (projectId, text) {                    // 2
        check(projectId, String);                                      // 3
        check(text, String);                                           // 4
        if (!Meteor.userId()) {                                        // 5
            throw new Meteor.Error("not-authorized");                  // 6
        }                                                              //
        if (!Projects.findOne(projectId)) {                            // 8
            throw new Meteor.Error("A project with id " + projectId + " doesn't exist");
        }                                                              //
        ProjectComments.insert({ "docId": projectId, "authorId": Meteor.userId(), "text": text }, function (err, res) {
            if (err) {                                                 // 12
                console.error(err);                                    // 13
            }                                                          //
            return res;                                                // 15
        });                                                            //
    }                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=comments.js.map
