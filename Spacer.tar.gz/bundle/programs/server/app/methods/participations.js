(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// methods/participations.js                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.methods({                                                       // 1
    upsertProjectParticipation: function (projectId, text) {           // 2
        check(projectId, String);                                      // 3
        check(text, String);                                           // 4
        if (!Meteor.userId()) {                                        // 5
            throw new Meteor.Error("not-authorized");                  // 6
        }                                                              //
        if (!Projects.findOne(projectId)) {                            // 8
            throw new Meteor.Error("A project with id " + projectId + " doesn't exist");
        }                                                              //
        Participations.upsert({ "projectId": projectId, "authorId": Meteor.userId() }, { $set: { "projectId": projectId, "authorId": Meteor.userId(), "text": text } }, function (err, res) {
            return res;                                                // 14
        });                                                            //
    },                                                                 //
    removeProjectParticipation: function (projectId) {                 // 17
        check(projectId, String);                                      // 18
        if (!Meteor.userId()) {                                        // 19
            throw new Meteor.Error("not-authorized");                  // 20
        }                                                              //
        if (!Projects.findOne(projectId)) {                            // 22
            throw new Meteor.Error("A project with id " + projectId + " doesn't exist");
        }                                                              //
        Participations.remove({ "projectId": projectId, "authorId": Meteor.userId() }, function (err, res) {
            return res;                                                //
        });                                                            //
    }                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=participations.js.map
