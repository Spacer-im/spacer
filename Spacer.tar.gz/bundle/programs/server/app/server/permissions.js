(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/permissions.js                                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
var allowAdmin = function (userId, doc) {                              // 1
    return userId && Roles.userIsInRole(userId, ['admin']);            // 2
};                                                                     //
                                                                       //
Articles.allow({                                                       // 5
    insert: allowAdmin,                                                // 6
    update: allowAdmin,                                                // 7
    remove: allowAdmin                                                 // 8
});                                                                    //
                                                                       //
Companies.allow({                                                      // 12
    insert: allowAdmin,                                                // 13
    update: allowAdmin,                                                // 14
    remove: allowAdmin                                                 // 15
});                                                                    //
                                                                       //
Jobs.allow({                                                           // 18
    insert: allowAdmin,                                                // 19
    update: allowAdmin,                                                // 20
    remove: allowAdmin                                                 // 21
});                                                                    //
                                                                       //
Projects.allow({                                                       // 25
    insert: allowAdmin,                                                // 26
    update: allowAdmin,                                                // 27
    remove: allowAdmin                                                 // 28
});                                                                    //
                                                                       //
SpEvents.allow({                                                       // 32
    insert: allowAdmin,                                                // 33
    update: allowAdmin,                                                // 34
    remove: allowAdmin                                                 // 35
});                                                                    //
                                                                       //
Images.allow({                                                         // 42
    insert: allowAdmin,                                                // 43
    update: allowAdmin,                                                // 44
    remove: allowAdmin,                                                // 45
    download: function () {                                            // 46
        return true;                                                   //
    }                                                                  //
});                                                                    //
                                                                       //
Avatars.allow({                                                        // 50
    insert: function (userId, doc) {                                   // 51
        return allowAdmin(userId) || userId && doc.owner === userId && Avatars.find({ owner: userId }).count() <= 5;
    },                                                                 //
    update: function (userId, doc) {                                   // 54
        return allowAdmin(userId) || userId && doc.owner === userId;   // 55
    },                                                                 //
    remove: function (userId, doc) {                                   // 57
        return allowAdmin(userId) || userId && doc.owner === userId;   // 58
    },                                                                 //
    download: function () {                                            // 60
        return true;                                                   //
    }                                                                  //
});                                                                    //
                                                                       //
UserImages.allow({                                                     // 63
    insert: function (userId, doc) {                                   // 64
        return allowAdmin(userId) || userId && doc.owner === userId && Avatars.find({ owner: userId }).count() <= 10;
    },                                                                 //
    update: function (userId, doc) {                                   // 67
        return allowAdmin(userId) || userId && doc.owner === userId;   // 68
    },                                                                 //
    remove: function (userId, doc) {                                   // 70
        return allowAdmin(userId) || userId && doc.owner === userId;   // 71
    },                                                                 //
    download: function () {                                            // 73
        return true;                                                   //
    }                                                                  //
});                                                                    //
                                                                       //
Meteor.users.deny({                                                    // 76
    update: function () {                                              // 77
        return true;                                                   // 78
    }                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=permissions.js.map
