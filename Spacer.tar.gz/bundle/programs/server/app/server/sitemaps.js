(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/sitemaps.js                                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
sitemaps.add('/sitemap.xml', function () {                             // 1
    // required: page                                                  //
    // optional: lastmod, changefreq, priority, xhtmlLinks, images, videos
    var pages = [{                                                     // 4
        page: '/',                                                     // 6
        lastmod: new Date(),                                           // 7
        changefreq: 'daily'                                            // 8
    }, {                                                               //
        page: "/community",                                            // 11
        lastmod: new Date(),                                           // 12
        changefreq: 'monthly'                                          // 13
    }, {                                                               //
        page: "/terms",                                                // 16
        lastmod: new Date(),                                           // 17
        changefreq: 'monthly'                                          // 18
    }, {                                                               //
        page: "/privacy",                                              // 22
        lastmod: new Date(),                                           // 23
        changefreq: 'monthly'                                          // 24
    }, {                                                               //
        page: "/about",                                                // 28
        lastmod: new Date(),                                           // 29
        changefreq: 'monthly'                                          // 30
    }, {                                                               //
        page: "/contact",                                              // 34
        lastmod: new Date(),                                           // 35
        changefreq: 'monthly'                                          // 36
    }, {                                                               //
        page: "/login",                                                // 39
        lastmod: new Date(),                                           // 40
        changefreq: 'monthly'                                          // 41
    }];                                                                //
                                                                       //
    Articles.find({}).forEach(function (doc) {                         // 45
        pages.push({ page: '/articles/' + doc.slug, lastmod: doc.createdAt });
    });                                                                //
                                                                       //
    pages.push({                                                       // 49
        page: "/jobs",                                                 // 50
        lastmod: Jobs.findOne({}, { sort: { createdAt: -1 } }).createdAt || new Date()
    });                                                                //
    Jobs.find({}).forEach(function (doc) {                             // 53
        pages.push({ page: '/jobs/' + doc.slug, lastmod: doc.createdAt });
    });                                                                //
                                                                       //
    pages.push({                                                       // 57
        page: "/jobs",                                                 // 58
        lastmod: Projects.findOne({}, { sort: { createdAt: -1 } }).createdAt || new Date()
    });                                                                //
    Projects.find({}).forEach(function (doc) {                         // 61
        pages.push({ page: '/projects/' + doc.slug, lastmod: doc.createdAt });
    });                                                                //
                                                                       //
    pages.push({                                                       // 65
        page: "/events",                                               // 66
        lastmod: SpEvents.findOne({}, { sort: { createdAt: -1 } }).createdAt || new Date()
    });                                                                //
    SpEvents.find({}).forEach(function (doc) {                         // 69
        pages.push({ page: '/events/' + doc.slug, lastmod: doc.createdAt });
    });                                                                //
    pages.push();                                                      // 72
                                                                       //
    return pages;                                                      // 74
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=sitemaps.js.map
