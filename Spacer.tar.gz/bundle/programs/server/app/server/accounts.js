(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/accounts.js                                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Accounts.onCreateUser(function (options, user) {                       // 1
    if (options.profile) {                                             // 2
        user.profile = options.profile;                                // 3
    }                                                                  //
    user.createdAt = new Date();                                       // 5
    return user;                                                       // 6
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=accounts.js.map
