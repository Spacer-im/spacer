(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/startup.js                                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
//AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY                             //
                                                                       //
Meteor.startup(function () {                                           // 3
    SetEmails.noreply();                                               // 4
    process.env.AWS_ACCESS_KEY_ID = Meteor.settings.aws.accessKeyId;   // 5
    process.env.AWS_SECRET_ACCESS_KEY = Meteor.settings.aws.secretAccessKey;
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=startup.js.map
