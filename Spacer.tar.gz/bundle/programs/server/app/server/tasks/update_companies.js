(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/tasks/update_companies.js                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
SyncedCron.add({                                                       // 1
    name: 'Get data from GlassDoor',                                   // 2
    schedule: function (parser) {                                      // 3
        // parser is a later.parse object                              //
        return parser.text(Meteor.settings.cron.glassDoorUpdateTime);  // 5
    },                                                                 //
    job: function () {                                                 // 7
        var text = "Results for companies update:\r\n\r\n";            // 8
        Companies.find().forEach(function (c) {                        // 9
            text += c.name + " -- " + c.glassDoorId + " -- ";          // 10
            if (c.glassDoorId) {                                       // 11
                var data = GlassDoor.getInfo(c.name, c.glassDoorId);   // 12
                text += data.overallRating + " \r\n";                  // 13
                Companies.update(c._id, { $set: { glassDoorData: data } });
            }                                                          //
        });                                                            //
                                                                       //
        if (Meteor.settings.cron.reportAddress) {                      // 18
            if (!process.env.MAIL_URL) {                               // 19
                SetEmails.noreply();                                   // 20
            }                                                          //
            Email.send({                                               // 22
                "from": "noreply@spacer.im",                           // 23
                "to": Meteor.settings.cron.reportAddress,              // 24
                "subject": "glassDoor update for " + new Date(),       // 25
                "text": text                                           // 26
            });                                                        //
        }                                                              //
    }                                                                  //
});                                                                    //
                                                                       //
//if (Meteor.settings.cron && Meteor.settings.cron.enable) {           //
//SyncedCron.start();                                                  //
//}                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=update_companies.js.map
