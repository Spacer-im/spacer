(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
function debugSleep(ms) {                                              // 1
    if (Meteor.settings.debug) {                                       // 2
        Meteor._sleepForMs(ms);                                        // 3
    }                                                                  //
}                                                                      //
                                                                       //
function clearFilter(inFilter) {                                       // 7
    inFilter = inFilter || {};                                         // 8
    var filter = {};                                                   // 9
    Object.keys(inFilter).forEach(function (k) {                       // 10
        if (inFilter[k]) {                                             // 11
            filter[k] = inFilter[k];                                   // 12
        }                                                              //
    });                                                                //
    return filter;                                                     // 15
}                                                                      //
                                                                       //
function generateOptions() {                                           // 18
    var limit = arguments.length <= 0 || arguments[0] === undefined ? 0 : arguments[0];
    var omitFields = arguments.length <= 1 || arguments[1] === undefined ? [] : arguments[1];
    var sortField = arguments.length <= 2 || arguments[2] === undefined ? "submitted" : arguments[2];
    var reverse = arguments.length <= 3 || arguments[3] === undefined ? true : arguments[3];
                                                                       //
    var options = {};                                                  // 19
    if (limit && limit > 0) {                                          // 20
        options.limit = limit;                                         // 21
    }                                                                  //
    if (omitFields && omitFields.length) {                             // 23
        options.fields = {};                                           // 24
        for (var _iterator = omitFields, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
            var _ref;                                                  //
                                                                       //
            if (_isArray) {                                            //
                if (_i >= _iterator.length) break;                     //
                _ref = _iterator[_i++];                                //
            } else {                                                   //
                _i = _iterator.next();                                 //
                if (_i.done) break;                                    //
                _ref = _i.value;                                       //
            }                                                          //
                                                                       //
            var f = _ref;                                              //
                                                                       //
            options.fields[f] = false;                                 // 26
        }                                                              //
    }                                                                  //
    if (sortField) {                                                   // 29
        options.sort = {};                                             // 30
        options.sort[sortField] = reverse ? -1 : 1;                    // 31
    }                                                                  //
    return options;                                                    // 33
}                                                                      //
                                                                       //
Meteor.smartPublish('articles', function (limit, filter) {             // 36
    filter = clearFilter(filter);                                      // 37
    this.addDependency("articles", "imageId", function (doc) {         // 38
        return Images.find(doc.imageId);                               //
    });                                                                //
    return Articles.find(filter, generateOptions(limit, ["text"], "createdAt"));
});                                                                    //
                                                                       //
Meteor.smartPublish("article", function (slug) {                       // 42
    this.addDependency("articles", "imageId", function (doc) {         // 43
        return Images.find(doc.imageId);                               //
    });                                                                //
    return Articles.find({ slug: slug });                              // 44
});                                                                    //
                                                                       //
Meteor.publish("tags", function () {                                   // 47
    return Tags.find();                                                // 48
});                                                                    //
                                                                       //
Meteor.smartPublish('jobs', function (limit, filter) {                 // 51
    filter = clearFilter(filter);                                      // 52
    this.addDependency("jobs", "companyName", function (doc) {         // 53
        return Companies.find({ name: doc.companyName });              //
    });                                                                //
    this.addDependency("companies", "imageId", function (doc) {        // 54
        return Images.find(doc.imageId);                               //
    });                                                                //
    return Jobs.find(filter, generateOptions(limit, ["description"], "createdAt"));
});                                                                    //
                                                                       //
Meteor.smartPublish("job", function (slug) {                           // 58
    this.addDependency("jobs", "companyName", function (doc) {         // 59
        return Companies.find({ name: doc.companyName });              //
    });                                                                //
    this.addDependency("companies", "imageId", function (doc) {        // 60
        return Images.find(doc.imageId);                               //
    });                                                                //
    return Jobs.find({ slug: slug });                                  // 61
});                                                                    //
                                                                       //
Meteor.smartPublish("companies", function (limit, filter) {            // 64
    filter = clearFilter(filter);                                      // 65
    this.addDependency("companies", "imageId", function (doc) {        // 66
        return Images.find(doc.imageId);                               //
    });                                                                //
    return Companies.find(filter, generateOptions(limit, ["text"]));   // 67
});                                                                    //
                                                                       //
Meteor.publish("companyNames", function () {                           // 70
    return Companies.find({}, { fields: { name: 1 } });                // 71
});                                                                    //
                                                                       //
Meteor.smartPublish("company", function (slug) {                       // 75
    this.addDependency("companies", "imageId", function (doc) {        // 76
        return Images.find(doc.imageId);                               //
    });                                                                //
    return Companies.find({ slug: slug });                             // 77
});                                                                    //
                                                                       //
Meteor.publish("featuredCompanies", function () {                      // 81
    return FeaturedCompanies.find({});                                 // 82
});                                                                    //
                                                                       //
Meteor.smartPublish("projects", function (limit, filter) {             // 85
    filter = clearFilter(filter);                                      // 86
    this.addDependency("projects", "imageId", function (doc) {         // 87
        return Images.find(doc.imageId);                               //
    });                                                                //
    return Projects.find(filter, generateOptions(limit, ["description"], "createdAt", true));
});                                                                    //
                                                                       //
Meteor.smartPublish("project", function (slug) {                       // 91
    var _this = this;                                                  //
                                                                       //
    this.addDependency("projects", "imageId", function (doc) {         // 92
        return Images.find(doc.imageId);                               //
    });                                                                //
    if (this.userId) {                                                 // 93
        this.addDependency("projects", "_id", function (doc) {         // 94
            return Participations.find({ authorId: _this.userId, projectId: doc._id });
        });                                                            //
    }                                                                  //
    return Projects.find({ slug: slug });                              // 97
});                                                                    //
                                                                       //
Meteor.publish("featuredProjects", function (limit) {                  // 100
    return Projects.find({}, generateOptions(limit, ["description"], "importance", true));
});                                                                    //
                                                                       //
Meteor.smartPublish("spEvents", function (limit, filter) {             // 104
    filter = clearFilter(filter);                                      // 105
    return SpEvents.find(filter, generateOptions(limit, ["text", "additionalText"]));
});                                                                    //
                                                                       //
Meteor.smartPublish("spEvent", function (slug) {                       // 109
    var userId = this.userId || "";                                    // 110
    return [SpEvents.find({ slug: slug }), SpEventRegistrations.find({ userId: userId })];
});                                                                    //
                                                                       //
Meteor.smartPublish("spEventRegistrations", function (slug) {          // 117
    var userId = this.userId || "";                                    // 118
    if (userId && Roles.userIsInRole(userId, ['admin'])) {             // 119
        this.addDependency("spEvents", "_id", function (doc) {         // 120
            return SpEventRegistrations.find({ eventId: doc._id });    //
        });                                                            //
        this.addDependency("spEventRegistrations", "userId", function (doc) {
            return Meteor.users.find({ _id: doc.userId });             //
        });                                                            //
        return SpEvents.find({ slug: slug });                          // 123
    } else {                                                           //
        return [];                                                     // 126
    }                                                                  //
});                                                                    //
                                                                       //
Meteor.smartPublish("profile", function (username) {                   // 131
    this.addDependency("users", "profile.photoId", function (doc) {    // 132
        return Avatars.find(doc.profile.photoId);                      //
    });                                                                //
    this.addDependency("users", "_id", function (doc) {                // 133
        return Participations.find({ authorId: doc._id });             //
    });                                                                //
    this.addDependency("participations", "projectId", function (doc) {
        return Projects.find(doc.projectId, { fields: { name: 1, slug: 1, imageId: 1 } });
    });                                                                //
    this.addDependency("projects", "imageId", function (doc) {         // 136
        return Images.find(doc.imageId);                               //
    });                                                                //
    return Meteor.users.find({ username: username }, { fields: { "_id": 1, "username": 1, profile: 1 } });
});                                                                    //
                                                                       //
Meteor.publish('countries', function () {                              // 140
    return Locations.find({});                                         // 141
});                                                                    //
                                                                       //
Meteor.publish('professions', function () {                            // 144
    return Professions.find({});                                       // 145
});                                                                    //
                                                                       //
Meteor.smartPublish("projectComments", function (limit, filter) {      // 148
    filter = clearFilter(filter);                                      // 149
    this.addDependency("projectComments", "authorId", function (doc) {
        return Meteor.users.find(doc.authorId, { fields: { "username": 1, "profile.photoId": 1 } });
    });                                                                //
    this.addDependency("users", "profile.photoId", function (doc) {    // 152
        return Avatars.find(doc.profile.photoId);                      //
    });                                                                //
    return ProjectComments.find(filter, generateOptions(limit, [], "createdAt", true));
});                                                                    //
                                                                       //
Meteor.publish('customPage', function (slug) {                         // 156
    return CustomPages.find({ slug: slug });                           // 157
});                                                                    //
                                                                       //
Meteor.publish(null, function () {                                     // 160
    return Phrases.find({});                                           //
});                                                                    //
                                                                       //
Meteor.publish(null, function () {                                     // 162
    return Meteor.roles.find({});                                      //
});                                                                    //
                                                                       //
Meteor.publish(null, function () {                                     // 164
    if (this.userId) {                                                 // 165
        var user = Meteor.users.findOne({ _id: this.userId });         // 166
        if (user && user.profile) {                                    // 167
            return Avatars.find(user.profile.photoId);                 // 168
        }                                                              //
    }                                                                  //
    this.ready();                                                      // 171
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publications.js.map
